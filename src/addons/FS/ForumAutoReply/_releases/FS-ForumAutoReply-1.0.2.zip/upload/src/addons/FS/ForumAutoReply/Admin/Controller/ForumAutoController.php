<?php

namespace FS\ForumAutoReply\Admin\Controller;

use Laminas\Stdlib\Parameters;
use XF\Admin\Controller\AbstractController;
use XF\Mvc\ParameterBag;

class ForumAutoController extends AbstractController
{
    public function actionIndex(ParameterBag $params)
    {
        $page = $this->filterPage();

        $perPage = 15;

        $from = (($perPage * $page) - $perPage) + 1;
        $start = $from - 1;
        $limit = $perPage;

        $result = $this->pagination($start, $limit);

        $prefixListData = $this->getPrefixRepo();

        $viewParams = [
            'data' => $result['data'],
            'nodeTree' => $this->getNodesRepo(),
            'userGroups' => $this->getUserGroupRepo()->findUserGroupsForList()->fetch(),
            'prefixGroups' => $prefixListData['prefixGroups'],
            'prefixesGrouped' => $prefixListData['prefixesGrouped'],
            'page' => $page,
            'perPage' => $perPage,
            'totalReturn' => $result['totalReturn'],
            'total' => $result['total']
        ];

        return $this->view('FS\ForumAutoReply:ForumAutoController\Index', 'forum_auto_reply_all', $viewParams);
    }

    public function actionAdd()
    {
        $message = $this->em()->create('FS\ForumAutoReply:ForumAutoReply');
        return $this->actionAddEdit($message);
    }

    public function actionEdit(ParameterBag $params)
    {
        /** @var \FS\ForumAutoReply\Entity\ForumAutoReply $message */
        $message = $this->assertMessageExists($params->message_id);
        return $this->messageAddEdit($message);
    }

    public function actionEditSingle(ParameterBag $params)
    {
        /** @var \FS\ForumAutoReply\Entity\ForumAutoReply $message */
        $message = $this->assertMessageExists($params->message_id);

        $viewParams = [
            'message' => $message
        ];

        return $this->view('FS\ForumAutoReply:ForumAutoController\EditSingle', 'forum_auto_reply_edit_single', $viewParams);
    }

    public function actionEditSave(ParameterBag $params)
    {
        $this->isExistedUser();

        $input = $this->filterMessageInputs();

        /** @var \FS\ForumAutoReply\Entity\ForumAutoReply $message */
        $message = $this->assertMessageExists($params->message_id);

        foreach ($input['words'] as $key => $value) {

            if ($value && $input['messages'][$key] && $input['from_users'][$key] != '') {

                $user = $this->finder('XF:User')->where('username', $input['from_users'][$key])->fetchOne();

                $message->word = $value;
                $message->message = $input['messages'][$key];
                $message->user_id = $user['user_id'];

                $message->save();
            }
        }

        return $this->messageAddEdit($message);
    }


    public function actionAddEdit(\FS\ForumAutoReply\Entity\ForumAutoReply $message)
    {

        $prefixListData = $this->getPrefixRepo();

        $viewParams = [

            'nodeTree' => $this->getNodesRepo(),
            'userGroups' => $this->getUserGroupRepo()->findUserGroupsForList()->fetch(),
            'prefixGroups' => $prefixListData['prefixGroups'],
            'prefixesGrouped' => $prefixListData['prefixesGrouped'],
        ];

        return $this->view('FS\ForumAutoReply:ForumAutoController\Add', 'forum_auto_reply_add', $viewParams);
    }

    protected function messageAddEdit(\FS\ForumAutoReply\Entity\ForumAutoReply $message)
    {
        $data = $this->finder('FS\ForumAutoReply:ForumAutoReply')->where('node_id', $message['node_id'])->where('prefix_id', '!=', NULL)
            ->with('User');

        $dataGroup = $this->finder('FS\ForumAutoReply:ForumAutoReply')->where('node_id', $message['node_id'])->where('prefix_id', '!=', NULL)
            ->with('User')->fetchOne();

        $noDataMatch = $this->finder('FS\ForumAutoReply:ForumAutoReply')->where('node_id', $message['node_id'])->where('no_match_prefix_id', '!=', NULL)
            ->with('User')->fetchOne();


        $prefixListData = $this->getPrefixRepo();

        // $noMatchUsers = $this->noMatchUserNames($noDataMatch['no_match_user_ids']);

        $viewParams = [
            'message' => $message,
            'nodeId' => $message['node_id'],
            'userGroupId' => $dataGroup['user_group_id'],
            'prefixId' => $dataGroup['prefix_id'],
            'noMatchPrefixId' => $noDataMatch['no_match_prefix_id'],
            'noMatchMessage' => $noDataMatch['no_match_message'],
            'noMatchUserIds' => $noDataMatch['no_match_user_ids'],
            'data' => $data->fetch(),
            'nodeTree' => $this->getNodesRepo(),
            'userGroups' => $this->getUserGroupRepo()->findUserGroupsForList()->fetch(),
            'prefixGroups' => $prefixListData['prefixGroups'],
            'prefixesGrouped' => $prefixListData['prefixesGrouped'],
        ];

        return $this->view('FS\ForumAutoReply:ForumAutoController\Add', 'forum_auto_reply_add', $viewParams);
    }

    // public function actionFind()
    // {
    //     // $q = ltrim($this->filter('q', 'array', ['no-trim']));
    //     $q = $this->filter('q', 'array', ['no-trim']);


    //     foreach ($q as $value) {
    //         /** @var \XF\Finder\User $userFinder */
    //         $userFinder = $this->finder('XF:User');

    //         $users = $userFinder
    //             ->where('username', 'like', $userFinder->escapeLike($value, '?%'));
    //         var_dump($users);
    //         exit;
    //     }
    //     var_dump($q);
    //     exit;
    //     if ($q !== '' && utf8_strlen($q) >= 2) {
    //         /** @var \XF\Finder\User $userFinder */
    //         $userFinder = $this->finder('XF:User');

    //         $users = $userFinder
    //             ->where('username', 'like', $userFinder->escapeLike($q, '?%'))
    //             ->isValidUser(true)
    //             ->fetch(10);
    //     } else {
    //         $users = [];
    //         $q = '';
    //     }

    //     $viewParams = [
    //         'q' => $q,
    //         'users' => $users
    //     ];
    //     // var_dump($viewParams);
    //     return $this->view('FS\ForumAutoReply:Member\Find', '', $viewParams);
    // }

    public function actionFind()
    {
        $q = ltrim($this->filter('q', 'str', ['no-trim']));

        // var_dump($q);
        if ($q !== '' && utf8_strlen($q) >= 2) {
            /** @var \XF\Finder\User $userFinder */
            $userFinder = $this->finder('XF:User');

            $users = $userFinder
                ->where('username', 'like', $userFinder->escapeLike($q, '?%'))
                ->isValidUser(true)
                ->fetch(10);
        } else {
            $users = [];
            $q = '';
        }

        $viewParams = [
            'q' => $q,
            'users' => $users
        ];
        // var_dump($viewParams);
        return $this->view('FS\ForumAutoReply:Member\Find', '', $viewParams);
    }

    public function actionSave(ParameterBag $params)
    {
        $input = $this->filterMessageInputs();

        // echo "<pre>";
        // print_r($input);
        // exit;
        // }str_replace("world","Peter","Hello world!")

        if ($params->message_id) {
            /** @var \FS\ForumAutoReply\Entity\ForumAutoReply $message */
            $message = $this->assertMessageExists($params->message_id);
            if ($message['node_id'] != $input['node_id']) {
                $this->isNodeExisted();
            }
            $this->preDeleteNodes($message);

            $this->messageSaveProcess();
        } else {
            $this->isNodeExisted();
            $this->messageSaveProcess();
        }

        return $this->redirect($this->buildLink('forumAutoReply'));
    }

    protected function messageSaveProcess()
    {
        $this->isNoMatchExisted();

        $input = $this->filterMessageInputs();

        foreach ($input['words'] as $key => $value) {

            $message = $this->em()->create('FS\ForumAutoReply:ForumAutoReply');

            if ($value && $input['messages'][$key] != '') {

                // $user = $this->finder('XF:User')->where('username', $input['from_users'][$key])->fetchOne();

                $message->node_id = $input['node_id'];
                $message->word = $value;
                $message->message = $input['messages'][$key];
                // $message->user_id = $user['user_id'];
                $message->user_group_id = $input['user_group_id'];
                $message->prefix_id = $input['prefix_id'];

                $message->save();
            }
        }

        return $this->redirect($this->buildLink('forumAutoReply'));
    }

    public function actionDelete(ParameterBag $params)
    {
        $replyExists = $this->assertMessageExists($params->message_id);

        /** @var \XF\ControllerPlugin\Delete $plugin */
        $plugin = $this->plugin('XF:Delete');
        return $plugin->actionDelete(
            $replyExists,
            $this->buildLink('forumAutoReply/delete', $replyExists),
            null,
            $this->buildLink('forumAutoReply'),
            "{$replyExists->word} - {$replyExists->message}"
        );
    }

    public function actionDeleteAll(ParameterBag $params)
    {
        /** @var \FS\ForumAutoReply\Entity\ForumAutoReply $replyExists */
        $replyExists = $this->assertMessageExists($params->message_id);

        /** @var \XF\ControllerPlugin\Delete $plugin */
        $plugin = $this->plugin('XF:Delete');

        if ($this->isPost()) {

            $this->preDeleteNodes($replyExists);

            return $this->redirect($this->buildLink('forumAutoReply'));
        }

        return $plugin->actionDelete(
            $replyExists,
            $this->buildLink('forumAutoReply/delete-all', $replyExists),
            null,
            $this->buildLink('forumAutoReply'),
            "Are you sure for delete this Forum ?"
        );
    }

    protected function filterMessageInputs()
    {
        return $this->filter([
            'node_id' => 'str',
            'words' => 'array',
            'messages' => 'array',
            'from_users' => 'array',
            'user_group_id' => 'str',
            'prefix_id' => 'str',

            'no_match_prefix_id' => 'str',
            'no_match_messages' => 'str',
            'no_match_users' => 'str',
        ]);
    }

    protected function isNodeExisted()
    {
        $input = $this->filterMessageInputs();

        $node = null;

        $node = $this->finder('FS\ForumAutoReply:ForumAutoReply')->where('node_id', $input['node_id'])->fetchOne();

        if ($node) {
            throw $this->exception($this->error(\XF::phraseDeferred('node_already_exist')));
        }
    }

    // protected function isExistedUser()
    // {
    //     $input = $this->filterMessageInputs();

    //     foreach ($input['from_users'] as $value) {

    //         $user = null;
    //         if ($value) {
    //             $user = $this->finder('XF:User')->where('username', $value)->fetchOne();

    //             if (!$user) {
    //                 throw $this->exception($this->error(\XF::phraseDeferred('requested_user_x_not_found', ['name' => $value])));
    //             }
    //         }
    //     }
    // }

    protected function isExistedUser()
    {

        $input = $this->filterMessageInputs();

        $users_names = explode(", ", $input['no_match_users']);

        $users_ids = array();

        foreach ($users_names as $value) {
            $user = null;
            if ($value) {
                $user = $this->em()->findOne('XF:User', ['username' => $value]);

                if (!$user) {
                    throw $this->exception($this->error(\XF::phraseDeferred('requested_user_x_not_found', ['name' => $value])));
                }
                array_push($users_ids, $user['user_id']);
            }
        }

        $user_ids = implode(", ", $users_ids);

        $viewParams = [
            'no_match_user_ids' => $user_ids
        ];

        return $viewParams;
    }

    protected function noMatchUserNames(ParameterBag $params)
    {

        $input = $this->filterMessageInputs();

        $users_names = explode(", ", $input['no_match_users']);

        $users_ids = array();

        foreach ($users_names as $value) {
            $user = null;
            if ($value) {
                $user = $this->em()->findOne('XF:User', ['username' => $value]);

                if (!$user) {
                    throw $this->exception($this->error(\XF::phraseDeferred('requested_user_x_not_found', ['name' => $value])));
                }
                array_push($users_ids, $user['user_id']);
            }
        }

        $user_ids = implode(", ", $users_ids);

        $viewParams = [
            'no_match_user_names' => $user_ids
        ];

        return $viewParams;
    }

    protected function isNoMatchExisted()
    {
        $users = $this->isExistedUser();

        $input = $this->filterMessageInputs();

        // $this->finder('FS\ForumAutoReply:ForumAutoReply')->where('node_id', $message['node_id'])
        //     ->with('User');

        $message = null;
        $message = $this->finder('FS\ForumAutoReply:ForumAutoReply')->where([
            'node_id' => $input['node_id'],
            ['no_match_message', '!=', null]
        ])->fetchOne();

        if (!$message) {
            $message = $this->em()->create('FS\ForumAutoReply:ForumAutoReply');
        }

        $message->node_id = $input['node_id'];
        $message->no_match_prefix_id = $input['no_match_prefix_id'];
        $message->no_match_message = $input['no_match_messages'];
        $message->no_match_user_ids = $users['no_match_user_ids'];
        $message->no_match_user_names = $input['no_match_users'];

        $message->save();
    }

    protected function preDeleteNodes(\FS\ForumAutoReply\Entity\ForumAutoReply $message)
    {
        $nodes = $this->finder('FS\ForumAutoReply:ForumAutoReply')->where('node_id', $message['node_id'])->fetch();

        foreach ($nodes as $node) {
            $node->delete();
        }
    }

    protected function pagination($start, $limit)
    {
        $db = \XF::db();
        $data = $db->fetchAll('SELECT node_id,MIN(message_id) as message_id ,MIN(user_group_id) as user_group_id ,MIN(prefix_id) as prefix_id FROM fs_forum_auto_reply GROUP BY node_id ORDER BY message_id DESC LIMIT ' . (int) $start . "," . (int) $limit);


        $total = count($db->fetchAll('SELECT node_id,MIN(message_id) as message_id ,MIN(user_group_id) as user_group_id ,MIN(prefix_id) as prefix_id FROM fs_forum_auto_reply GROUP BY node_id'));

        $viewParams = [
            'data' => $data,
            'total' => $total,
            'totalReturn' => count($data),
        ];

        return $viewParams;
    }

    /**
     * @return \XF\Repository\UserGroup
     */
    protected function getUserGroupRepo()
    {
        return $this->repository('XF:UserGroup');
    }

    /**
     * @return \XF\Repository\Node
     */
    protected function getNodesRepo()
    {
        /** @var \XF\Repository\Node $nodeRepo */
        $nodeRepo = \XF::repository('XF:Node');
        $nodeTree = $nodeRepo->createNodeTree($nodeRepo->getFullNodeList());

        return $nodeTree;
    }

    /**
     * @return \XF\Repository\ThreadPrefix
     */
    protected function getPrefixRepo()
    {
        /** @var \XF\Repository\ThreadPrefix $prefixRepo */
        $prefixRepo = $this->repository('XF:ThreadPrefix');
        $prefixListData = $prefixRepo->getPrefixListData();

        return $prefixListData;
    }

    /**
     * @param string $id
     * @param array|string|null $with
     * @param null|string $phraseKey
     *
     * @return \CRUD\XF\Entity\Crud
     */
    protected function assertMessageExists($id, array $extraWith = [], $phraseKey = null)
    {
        return $this->assertRecordExists('FS\ForumAutoReply:ForumAutoReply', $id, $extraWith, $phraseKey);
    }
}
