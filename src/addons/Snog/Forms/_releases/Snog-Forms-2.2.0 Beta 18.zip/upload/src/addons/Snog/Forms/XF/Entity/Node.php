<?php

namespace Snog\Forms\XF\Entity;


/**
 * @property int $snog_posid
 * @property string $snog_label
 */
class Node extends XFCP_Node
{
}