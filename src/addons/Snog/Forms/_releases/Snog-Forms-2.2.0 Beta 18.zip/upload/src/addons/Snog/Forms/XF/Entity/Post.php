<?php

namespace Snog\Forms\XF\Entity;


/**
 * Class Post
 * @package Snog\Forms\XF\Entity
 *
 * @property \Snog\Forms\Entity\Promotion $Promotions
 */
class Post extends XFCP_Post
{
}